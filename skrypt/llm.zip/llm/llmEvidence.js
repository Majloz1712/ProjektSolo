// skrypt/llm/llmEvidence.js
// Evidence extraction v2:
// - Build short verbatim candidate snippets deterministically (so we never "hallucinate" quotes).
// - LLM only selects candidate IDs relevant to USER_PROMPT.
// - Returned quotes are always exact substrings of the chunk.

import { generateTextWithOllama } from './ollamaClient.js';

const DEFAULT_MAX_CHUNKS = 14;
const DEFAULT_MAX_CANDIDATES_PER_CHUNK = parseInt(
  process.env.EVIDENCE_MAX_CANDIDATES_PER_CHUNK || '12',
  10
);
const DEFAULT_WINDOW_CHARS = parseInt(
  process.env.EVIDENCE_WINDOW_CHARS || '48',
  10
);
const DEFAULT_MAX_QUOTE_LEN = parseInt(
  process.env.EVIDENCE_MAX_QUOTE_LEN || '160',
  10
);

// Optional heuristic noise filters (OFF by default).
// Enable via: LLM_EVIDENCE_HEURISTICS=true
const EVIDENCE_HEURISTICS_ENABLED =
  String(process.env.LLM_EVIDENCE_HEURISTICS || 'false')
    .trim()
    .toLowerCase() === 'true';

function clamp(n, lo, hi) {
  return Math.max(lo, Math.min(hi, n));
}

function isWs(ch) {
  return ch === ' ' || ch === '\n' || ch === '\t' || ch === '\r' || ch === '\f' || ch === '\v';
}

function trimToWsBoundaries(text, s, e) {
  let start = s;
  let end = e;

  // move start left to whitespace boundary if we are in the middle of a token
  while (start > 0 && !isWs(text[start - 1]) && !isWs(text[start])) start--;
  // move end right to whitespace boundary
  while (end < text.length && !isWs(text[end - 1]) && !isWs(text[end])) end++;

  start = clamp(start, 0, text.length);
  end = clamp(end, 0, text.length);
  return [start, end];
}

function extractWindow(text, matchStart, matchEnd, opts = {}) {
  const win = opts.windowChars ?? DEFAULT_WINDOW_CHARS;
  const maxLen = opts.maxLen ?? DEFAULT_MAX_QUOTE_LEN;

  if (!text || typeof text !== 'string') return '';

  let s = clamp(matchStart - win, 0, text.length);
  let e = clamp(matchEnd + win, 0, text.length);
  [s, e] = trimToWsBoundaries(text, s, e);

  let snippet = text.slice(s, e).trim();
  if (snippet.length <= maxLen) return snippet;

  // shrink deterministically around the match
  const midWin = Math.max(18, Math.floor((maxLen - (matchEnd - matchStart)) / 2));
  s = clamp(matchStart - midWin, 0, text.length);
  e = clamp(matchEnd + midWin, 0, text.length);
  [s, e] = trimToWsBoundaries(text, s, e);
  snippet = text.slice(s, e).trim();

  if (snippet.length > maxLen) {
    // last resort: hard cut but still verbatim
    snippet = snippet.slice(0, maxLen).trim();
  }

  return snippet;
}

const DEFAULT_WINDOW_WORDS = Number.parseInt(process.env.EVIDENCE_WINDOW_WORDS || '3', 10);

function extractWindowByWords(text, matchStart, matchEnd, opts = {}) {
  const words = Math.max(0, opts.windowWords ?? DEFAULT_WINDOW_WORDS);
  const maxLen = opts.maxLen ?? DEFAULT_MAX_QUOTE_LEN;
  if (!text || typeof text !== 'string') return '';
  if (words === 0) return extractWindow(text, matchStart, matchEnd, opts);

  const spans = [];
  const re = /\S+/g;
  let m;
  while ((m = re.exec(text))) {
    spans.push([m.index, m.index + m[0].length]);
    if (spans.length > 5000) break;
  }
  if (!spans.length) return extractWindow(text, matchStart, matchEnd, opts);

  let sIdx = 0;
  while (sIdx < spans.length && spans[sIdx][1] <= matchStart) sIdx++;
  if (sIdx >= spans.length) sIdx = spans.length - 1;

  let eIdx = sIdx;
  while (eIdx < spans.length && spans[eIdx][0] < matchEnd) eIdx++;
  eIdx = Math.max(sIdx, eIdx - 1);

  const startTok = clamp(sIdx - words, 0, spans.length - 1);
  const endTok = clamp(eIdx + words, 0, spans.length - 1);

  let s = spans[startTok][0];
  let e = spans[endTok][1];
  [s, e] = trimToWsBoundaries(text, s, e);

  let snippet = text.slice(s, e).trim();
  if (snippet.length <= maxLen) return snippet;

  // fallback: keep verbatim but shrink by char-window
  return extractWindow(text, matchStart, matchEnd, { ...opts, maxLen });
}

function extractWindowSmart(text, matchStart, matchEnd, opts = {}) {
  return extractWindowByWords(text, matchStart, matchEnd, opts);
}

function normKey(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/["'`]/g, '')
    .trim();
}

function pushCandidate(out, seen, id, quote, kind) {
  const q = String(quote || '').trim();
  if (!q) return;
  const key = normKey(q);
  if (!key || seen.has(key)) return;
  seen.add(key);
  out.push({ id, quote: q, kind });
}

function escapeRegExp(str) {
  return String(str || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

const PROMPT_STOPWORDS = new Set([
  // Polish / generic connectors
  'i','a','o','w','z','za','do','na','od','po','pod','nad','oraz','lub',
  'tylko','gdy','kiedy','że','ze','sie','się','nie','tak','jak','żeby','zeby','aby',
  // common prompt words
  'monitoruj','monitorować','monitorowac','powiadom','powiadomić','powiadomic','ignoruj','ignore',
  'oferta','oferte','strona','strony','elementy','pozostałe','pozostale',
  // platform generic
  'allegro',
  // very generic nouns
  'produkt','produktu'
]);

function extractPromptKeywords(userPrompt, max = 10) {
  const p = String(userPrompt || '').toLowerCase();
  const words = p.match(/[\p{L}\p{N}]+/gu) || [];
  const uniq = [];
  for (const w of words) {
    if (w.length < 4) continue;
    if (PROMPT_STOPWORDS.has(w)) continue;
    if (!uniq.includes(w)) uniq.push(w);
    if (uniq.length >= max) break;
  }
  return uniq;
}

function promptWantsSellerInfo(userPromptLower) {
  return /sprzedaw/.test(userPromptLower) || /seller/.test(userPromptLower);
}

function hasReviewHintLower(s) {
  return /(opin|recenz|review|rating|ocen|gwiazd|★|\/5|\/10)/.test(s);
}

function isSellerPercentContextLower(s) {
  return /(sprzedaw|w ostatnich|miesiac|kupujacych\s+polec|polec\w*\s+tego\s+sprzedaw|firma\s+poleca)/.test(s);
}

function isPriceOrDeliveryNoiseLower(s) {
  return /(\bzł\b|\bzl\b|pln|smart|rat|dostaw|kup\s+do|zaplac|pay|\b\d{1,2}:\d{2}\b)/.test(s);
}
function buildCandidatesForChunk(chunkText, chunkId, opts = {}) {
  const text = String(chunkText || "");
  const maxCandidates = Number.isFinite(opts.maxCandidates) ? opts.maxCandidates : DEFAULT_MAX_CANDIDATES_PER_CHUNK;
  const userPrompt = String(opts.userPrompt || "");
  const userPromptLower = userPrompt.toLowerCase();
  const promptKeywords = Array.isArray(opts.promptKeywords) ? opts.promptKeywords : [];
  const seen = new Set();
  const out = [];


  // Priority patterns first: rating-like and review-like signals.
  const patterns = [
    { kind: 'rating_frac', re: /\b\d{1,2}(?:[.,]\d{1,2})?\s*\/\s*(?:5|10)\b/g },
    { kind: 'rating_num_stars', re: /\b\d{1,2}(?:[.,]\d{1,2})?\s*[★☆]{1,6}\b/g },
    { kind: 'stars', re: /[★☆]{3,}/g },
    { kind: 'percent', re: /\b\d{1,3}(?:[.,]\d{1,2})?\s*%/g },
    // counts near review-ish keywords (multi-language-ish, short stems)
    {
      kind: 'count_with_keyword',
      re: /\b\d+\s*(?:opin|opini|ocen|oceny|review|reviews|recenz|rating|ratings)\w*/gi,
    },
  ];

  // Additional keyword-only anchors, low priority.
  const keywordRe = /\b(?:opinie|opinia|ocena|oceny|recenzja|recenzje|review|reviews|rating|ratings)\b/gi;

  let idx = 0;
  for (const p of patterns) {
    p.re.lastIndex = 0;
    let m;
    while ((m = p.re.exec(text)) !== null) {
      const start = m.index;
      const end = start + m[0].length;
      const quote = extractWindowSmart(text, start, end);
      pushCandidate(out, seen, `cand#${chunkId}#${idx++}`, quote, p.kind);
      if (out.length >= maxCandidates) return out;
      // Avoid infinite loops on zero-length matches.
      if (m.index === p.re.lastIndex) p.re.lastIndex++;
    }
  }

  // Keyword anchors: give some context around the keyword (helps when OCR splits counts elsewhere).
  keywordRe.lastIndex = 0;
  let km;
  while ((km = keywordRe.exec(text)) !== null) {
    const start = km.index;
    const end = start + km[0].length;
    const quote = extractWindowSmart(text, start, end);
    pushCandidate(out, seen, `cand#${chunkId}#${idx++}`, quote, 'keyword');
    if (out.length >= maxCandidates) return out;
    if (km.index === keywordRe.lastIndex) keywordRe.lastIndex++;
  }

  // Prompt-keyword candidates: anchor on significant words from USER_PROMPT.
  if (promptKeywords.length && out.length < maxCandidates) {
    for (const kw of promptKeywords) {
      if (out.length >= maxCandidates) break;
      const re = new RegExp(escapeRegExp(kw), 'ig');
      let m;
      while ((m = re.exec(text))) {
        const quote = extractWindowSmart(text, m.index, m.index + m[0].length, { windowWords: 3 });
        pushCandidate(out, seen, `cand#${chunkId}#${idx++}`, quote, 'prompt_kw');
        if (out.length >= maxCandidates) break;
        if (m.index === re.lastIndex) re.lastIndex++;
      }
    }
  }

  // Optional heuristic noise filter (OFF by default).
  if (!EVIDENCE_HEURISTICS_ENABLED) {
    return out.slice(0, maxCandidates);
  }

  // Filter common seller-% noise unless prompt explicitly asks about seller.
  const wantsSeller = promptWantsSellerInfo(userPromptLower);
  const filtered = [];
  for (const c of out) {
    const ql = String(c.quote || '').toLowerCase();
    if (c.kind === 'percent' && !wantsSeller) {
      if (isSellerPercentContextLower(ql)) continue;
      if (isPriceOrDeliveryNoiseLower(ql) && !hasReviewHintLower(ql)) continue;
    }
    filtered.push(c);
  }

  return filtered.slice(0, maxCandidates);
}

function fallbackSelectCandidatesDeterministic(chunksWithCandidates) {
  // If LLM fails, we need a deterministic fallback.
  // By default keep it minimal (no heuristic ranking) to preserve universality.
  // Enable heuristic ranking via: LLM_EVIDENCE_HEURISTICS=true
  const priority = EVIDENCE_HEURISTICS_ENABLED
    ? {
        rating_frac: 1,
        rating_num_stars: 2,
        stars: 3,
        percent: 4,
        count_with_keyword: 5,
        keyword: 6,
      }
    : null;

  const items = [];
  const byChunk = {};
  const focusChunkIds = [];

  for (const c of chunksWithCandidates) {
    const base = [...(c.candidates || [])];
    const sorted = priority
      ? base.sort((a, b) => {
          const pa = priority[a.kind] || 999;
          const pb = priority[b.kind] || 999;
          if (pa !== pb) return pa - pb;
          return a.quote.length - b.quote.length;
        })
      : base; // preserve original deterministic order

    const chosen = sorted.slice(0, 2).map((x) => x.id);
    if (chosen.length) {
      focusChunkIds.push(c.id);
      byChunk[c.id] = { relevant: true, chosen };
      for (const id of chosen) {
        const found = sorted.find((x) => x.id === id);
        if (found) items.push({ id: `evidence#${id}`, chunk_id: c.id, quote: found.quote });
      }
    } else {
      byChunk[c.id] = { relevant: false, chosen: [] };
    }
  }

  return { items, focusChunkIds, byChunk, llmFailed: true };
}

export async function extractEvidenceFromChunksLLM({
  chunks,
  userPrompt,
  model,
  maxChunks = DEFAULT_MAX_CHUNKS,
}) {
  const prompt = String(userPrompt || '').trim();
  const promptKeywords = extractPromptKeywords(prompt);

  const list = Array.isArray(chunks) ? chunks : [];
  const slice = list.slice(0, Math.max(1, maxChunks));

  // 1) Deterministically build candidates per chunk.
  const chunksWithCandidates = slice.map((c) => {
    const id = String(c?.id || '');
    const title = String(c?.title || '').slice(0, 140);
    const text = String(c?.text || '');
    const candidates = buildCandidatesForChunk(text, id, { userPrompt: prompt, promptKeywords });
    return { id, title, candidates };
  });

  const totalCandidates = chunksWithCandidates.reduce(
    (acc, c) => acc + (c.candidates ? c.candidates.length : 0),
    0
  );

  if (!prompt || totalCandidates === 0) {
    const byChunk = {};
    for (const c of chunksWithCandidates) byChunk[c.id] = { relevant: false, chosen: [] };
    return { items: [], focusChunkIds: [], byChunk };
  }

  // 2) Ask LLM to select candidate IDs.
  const schema = {
    type: 'object',
    additionalProperties: false,
    required: ['chunks'],
    properties: {
      chunks: {
        type: 'array',
        minItems: 1,
        maxItems: maxChunks,
        items: {
          type: 'object',
          additionalProperties: false,
          required: ['id', 'relevant', 'chosen'],
          properties: {
            id: { type: 'string', minLength: 1, maxLength: 64 },
            relevant: { type: 'boolean' },
            chosen: {
              type: 'array',
              items: { type: 'string', minLength: 1, maxLength: 128 },
              maxItems: 6,
            },
          },
        },
      },
    },
  };

  const system = `Jesteś ekstraktorem dowodów dla monitoringu zmian na stronie.
Dostajesz USER_PROMPT oraz listę chunków, a w każdym chunku listę KANDYDATÓW (krótkie, dosłowne fragmenty OCR).
Twoje zadanie: wybrać ID kandydatów, które są BEZPOŚREDNIO związane z USER_PROMPT (np. opinie/recenzje/ocena produktu).

Zasady wyboru:
- Jeśli USER_PROMPT dotyczy opinii/recenzji/oceny: preferuj kandydaty zawierające ocenę (np. X/5, gwiazdki ★), procent polecenia (np. 92%) i/lub liczbę opinii/recenzji; unikaj luźnych opisów bez liczb.
- NIE wybieraj fragmentów o cenie, dostawie, ratach, parametrach technicznych itp., jeśli USER_PROMPT mówi je ignorować.
- Jeśli nie masz pewności, NIE wybieraj.

Zwróć WYŁĄCZNIE JSON zgodny ze schematem. chosen może zawierać tylko ID z candidates dla danego chunka.`;

  const llmInput = {
    userPrompt: prompt,
    chunks: chunksWithCandidates.map((c) => ({
      id: c.id,
      title: c.title,
      candidates: c.candidates.map((x) => ({ id: x.id, text: x.quote })),
    })),
  };

  let parsed;
  try {
    const resp = await generateTextWithOllama({
      model,
      system,
      prompt: JSON.stringify(llmInput),
      format: schema,
      temperature: 0,
    });

    if (!resp?.ok) throw new Error(resp?.error || 'ollama_failed');

    parsed = resp?.json;
    if (!parsed || !Array.isArray(parsed.chunks)) throw new Error('bad_json');
  } catch (e) {
    return fallbackSelectCandidatesDeterministic(chunksWithCandidates);
  }

  // 3) Validate & materialize evidence items.
  const candIndex = new Map();
  for (const c of chunksWithCandidates) {
    for (const x of c.candidates || []) {
      candIndex.set(x.id, { chunkId: c.id, quote: x.quote });
    }
  }

  const byChunk = {};
  const focusChunkIds = [];
  const items = [];

  for (const ch of parsed.chunks) {
    const chunkId = String(ch?.id || '');
    const relevant = Boolean(ch?.relevant);
    const chosen = Array.isArray(ch?.chosen) ? ch.chosen : [];

    const validChosen = chosen.filter((id) => {
      const info = candIndex.get(id);
      return info && info.chunkId === chunkId;
    });

    const finalRelevant = relevant && validChosen.length > 0;
    byChunk[chunkId] = { relevant: finalRelevant, chosen: validChosen };

    if (finalRelevant) focusChunkIds.push(chunkId);

    for (const cid of validChosen.slice(0, 6)) {
      const info = candIndex.get(cid);
      if (info?.quote) items.push({ id: `evidence#${cid}`, chunk_id: chunkId, quote: info.quote });
    }
  }

  // Ensure stable order
  items.sort((a, b) => String(a.id).localeCompare(String(b.id)));

  return { items, focusChunkIds, byChunk };
}
